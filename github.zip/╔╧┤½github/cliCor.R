






clinical=read.table("clinical1.txt", header=T, sep="\t", check.names=F, row.names=1)
cluster=read.table("cluster2.txt", header=T, sep="\t", check.names=F, row.names=1)
sameSample=intersect(row.names(clinical), row.names(cluster))
clinical=clinical[sameSample,,drop=F]
cluster=cluster[sameSample,,drop=F]
data=cbind(clinical, cluster)
for(i in colnames(data)[1:(ncol(data)-1)]){
    rt=data[,c("cluster",i)]
    colnames(rt)=c("Cluster","type")
    tableStat=table(rt)
	stat=chisq.test(tableStat)
	pvalue=stat$p.value
	if(pvalue<0.001){
		pvalue="p<0.001"
	}else{
		pvalue=paste0("p=",sprintf("%.03f",pvalue))
	p=ggplot(rt, aes(Cluster)) + 
	    geom_bar(aes(fill=type), position="fill")+
	    labs(x = 'Cluster',y = '',title=paste0(i," (",pvalue,")"))+
	    guides(fill = guide_legend(title =i))+
	    theme_bw()+
	    theme(plot.title = element_text(hjust = 0.5))
    pdf(file=paste0("cliCor.",i,".pdf"),width=4.5,height=6)	
	print(p)
	dev.off()



