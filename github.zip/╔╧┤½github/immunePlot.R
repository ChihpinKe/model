






immFile="CIBERSORT-Results.txt"     
cluFile="cluster.txt"         
pFilter=0.05           
immune=read.table(immFile, header=T, sep="\t", check.names=F, row.names=1)
row.names(immune)=gsub("(.*?)\\-(.*?)\\-(.*?)\\-(.*?)\\-.*", "\\1\\-\\2\\-\\3", row.names(immune))
immune=avereps(immune)
immune=immune[immune[,"P-value"]<pFilter,]
data=as.matrix(immune[,1:(ncol(immune)-3)])
cluster=read.table(cluFile, header=T, sep="\t", check.names=F, row.names=1)
sameSample=intersect(row.names(data), row.names(cluster))
data=cbind(data[sameSample,,drop=F], cluster[sameSample,,drop=F])
data=data[order(data$cluster),]
gaps=c(1, as.vector(cumsum(table(data$cluster))))
xlabels=levels(factor(data$cluster))
bioCol=c("#0066FF","#FF9900","#FF0000","#6E568C","#7CC767","#223D6C","#D20A13","#FFD121","#088247","#11AA4D")
data1=t(as.matrix(data[,-ncol(data)]))
pdf("barplot.pdf",height=10,width=18)
col=rainbow(nrow(data1),s=0.7,v=0.7)
par(las=1,mar=c(8,5,4,16),mgp=c(3,0.1,0),cex.axis=1.5)
a1=barplot(data1,col=col,yaxt="n",ylab="Relative Percent",xaxt="n",cex.lab=1.8)
a2=axis(2,tick=F,labels=F)
axis(2,a2,paste0(a2*100,"%"))
par(srt=0,xpd=T)
for(i in 1:length(gaps)){
	j=i+1
	rect(xleft=a1[gaps[i]], ybottom = -0.01, xright = a1[gaps[j]], ytop= -0.06, col=bioCol[i])
	text((a1[gaps[i]]+a1[gaps[j]])/2,-0.035,xlabels[i],cex=2)
ytick2 = cumsum(data1[,ncol(data1)])
ytick1 = c(0,ytick2[-length(ytick2)])
legend(par('usr')[2]*0.98,par('usr')[4],legend=rownames(data1),col=col,pch=15,bty="n",cex=1.3)
dev.off()
data=melt(data,id.vars=c("cluster"))
colnames(data)=c("cluster", "Immune", "Expression")
group=levels(factor(data$cluster))
data$cluster=factor(data$cluster, levels=group)
bioCol=c("#0066FF","#FF9900","#FF0000","#6E568C","#7CC767","#223D6C","#D20A13","#FFD121","#088247","#11AA4D")
bioCol=bioCol[1:length(group)]
boxplot=ggboxplot(data, x="Immune", y="Expression", fill="cluster",
				  xlab="",
				  ylab="Fraction",
				  legend.title="Cluster",
				  width=0.8,
				  palette=bioCol)+
				  rotate_x_text(50)+
	stat_compare_means(aes(group=cluster),symnum.args=list(cutpoints=c(0, 0.001, 0.01, 0.05, 1), symbols=c("***", "**", "*", "ns")), label="p.signif")
pdf(file="immune.diff.pdf", width=7, height=6)
print(boxplot)



